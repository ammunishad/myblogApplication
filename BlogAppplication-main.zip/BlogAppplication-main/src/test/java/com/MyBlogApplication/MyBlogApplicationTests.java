package com.MyBlogApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
